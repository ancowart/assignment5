# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Propertymanagement::Application.config.secret_key_base = '0e26676371975ec2989bd73d7939e85bf1c681a9f68b61acf9f43fab874456034b211f2134f0511b9f6890e70e18a73dbea3e4d4cb01db0c6789deab6427bb4a'
