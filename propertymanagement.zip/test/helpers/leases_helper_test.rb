require 'test_helper'

class LeasesHelperTest < ActionView::TestCase
end
