module PropertiesHelper
end
