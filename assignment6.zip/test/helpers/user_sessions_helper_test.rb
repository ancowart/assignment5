require 'test_helper'

class UserSessionsHelperTest < ActionView::TestCase
end
