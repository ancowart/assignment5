require 'test_helper'

class UserSessionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
